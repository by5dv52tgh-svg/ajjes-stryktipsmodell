# Ajjes Stryktipsmodell v2

Privat Streamlit-app för Stryktips. Ladda upp CSV, kör sannolikhetsmodell, bygg system och backtest.

Start: `pip install -r requirements.txt` och `streamlit run app.py`.
